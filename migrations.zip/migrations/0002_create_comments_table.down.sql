DROP TABLE comments;
